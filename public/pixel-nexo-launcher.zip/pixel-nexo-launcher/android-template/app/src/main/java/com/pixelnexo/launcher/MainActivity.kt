package com.pixelnexo.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Pixel Nexo Dev Launcher
 * Launcher nativo para desenvolvedores Android e criadores digitais.
 * Identidade: Dourado (#F5B942) e Roxo Noturno (#23083B).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var appRecyclerView: RecyclerView
    private lateinit var appAdapter: AppListAdapter
    private var installedAppsList: List<AppItem> = listOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        appRecyclerView = findViewById(R.id.recyclerViewApps)
        appRecyclerView.layoutManager = GridLayoutManager(this, 4)

        loadInstalledApplications()
    }

    private fun loadInstalledApplications() {
        val packageManager = packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos: List<ResolveInfo> = packageManager.queryIntentActivities(mainIntent, 0)
        
        installedAppsList = resolveInfos.map { resolveInfo ->
            AppItem(
                label = resolveInfo.loadLabel(packageManager).toString(),
                packageName = resolveInfo.activityInfo.packageName,
                icon = resolveInfo.loadIcon(packageManager)
            )
        }.sortedBy { it.label.lowercase() }

        appAdapter = AppListAdapter(installedAppsList) { app ->
            val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName)
            if (launchIntent != null) {
                startActivity(launchIntent)
            }
        }
        appRecyclerView.adapter = appAdapter
    }

    // Impede que o botão voltar feche o Launcher
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // No-op: Mantém o usuário na tela inicial do launcher
    }
}

data class AppItem(
    val label: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

class AppListAdapter(
    private val apps: List<AppItem>,
    private val onAppClick: (AppItem) -> Unit
) : RecyclerView.Adapter<AppListAdapter.AppViewHolder>() {

    class AppViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val iconImageView: ImageView = view.findViewById(R.id.imageViewAppIcon)
        val nameTextView: TextView = view.findViewById(R.id.textViewAppName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app_icon, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val app = apps[position]
        holder.nameTextView.text = app.label
        holder.iconImageView.setImageDrawable(app.icon)
        holder.itemView.setOnClickListener { onAppClick(app) }
    }

    override fun getItemCount(): Int = apps.size
}
