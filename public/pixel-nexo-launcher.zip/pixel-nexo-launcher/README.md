# 🚀 Pixel Nexo Dev Launcher (Android & Web PWA)

Bem-vindo ao **Pixel Nexo Dev Launcher**, um launcher Android moderno projetado para desenvolvedores e criadores digitais. O projeto combina identidade visual refinada (tons de roxo `#23083B` e dourado `#F5B942`), terminais interativos (Bash, GitHub CLI, Google Drive CLI), sistema de abas de fichário por ambientes e código nativo em Kotlin.

---

## 📱 Como Rodar Localmente (Web / PWA)

1. Instale as dependências:
   ```bash
   npm install
   ```
2. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
3. Abra no navegador:
   ```text
   http://localhost:3000
   ```
4. Para compilar a versão estática otimizada de produção:
   ```bash
   npm run build
   ```

---

## 📲 Como Instalar no Celular via PWA (1-Clique)

1. Acesse o link da aplicação no navegador do celular:
   - **Android (Chrome)**: Toque nos três pontinhos verticais (`⋮`) e selecione **"Instalar aplicativo"** ou **"Adicionar à tela inicial"**.
   - **iPhone (Safari)**: Toque no botão de Compartilhar (`⎋`) e selecione **"Adicionar à Tela de Início"**.
2. O aplicativo funcionará em tela cheia com ícone próprio na sua gaveta de apps, sem barras do navegador e com suporte offline.

---

## 🤖 Como Compilar como APK Nativo Android (Android Studio)

O projeto inclui o código Kotlin completo do Launcher Android nos arquivos do projeto:

1. Abra o **Android Studio** e crie um novo projeto Android com suporte a Kotlin.
2. Defina o pacote:
   ```kotlin
   package com.pixelnexo.launcher
   ```
3. No arquivo `AndroidManifest.xml`, configure a Activity principal com as categorias de Launcher:
   ```xml
   <activity
       android:name=".MainActivity"
       android:exported="true"
       android:launchMode="singleTask">
       <intent-filter>
           <action android:name="android.intent.action.MAIN" />
           <category android:name="android.intent.category.HOME" />
           <category android:name="android.intent.category.DEFAULT" />
       </intent-filter>
   </activity>
   ```
4. No arquivo `build.gradle.kts (Module: app)` adicione:
   ```kotlin
   dependencies {
       implementation("androidx.core:core-ktx:1.12.0")
       implementation("androidx.appcompat:appcompat:1.6.1")
       implementation("com.google.android.material:material:1.11.0")
   }
   ```
5. No menu do Android Studio, clique em:
   `Build > Build Bundle(s) / APK(s) > Build APK(s)`
6. Transfira e instale o `.apk` gerado no seu celular Android!

---

## 🎨 Identidade Visual Pixel Nexo
- **Fundo Principal:** `#160324` / `#23083B`
- **Dourado Pixel Nexo:** `#F5B942`
- **Violeta de Destaque:** `#8022B8`
- **Modos de Fichário:** Nexo, Dev, Work, Social e Ops
